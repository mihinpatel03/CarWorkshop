import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import { NavigationContainer } from "@react-navigation/native";
import { createDrawerNavigator } from "@react-navigation/drawer";
import HomeScreen from "../screens/Home/HomeScreen";
import DrawerContainer from "../screens/DrawerContainer/DrawerContainer";
import SearchScreen from "../screens/Search/SearchScreen";
import Login from "../screens/Login/Login";
import SignUpMember from "../screens/Login/SignUp";
import LoginHome from "../screens/Login/LoginHome";
import ProviderRegistration from "../screens/Login/ProviderSignUp";
import ProviderHome from "../screens/providers/ProvidersHome";
import AddService from "../screens/providers/AddService";
import ServiceListForProviders from "../screens/providers/ListServices";
import LoginUser from "../screens/Login/LoginUser";
import SearchItems from "../screens/Home/SearchItems";
import ListWorkShops from "../screens/Home/ListWorkshops";
import FinalSubmit from "../screens/Home/FinalSubmit";
import ConfirmService from "../screens/providers/ConfirmService";
import historyAdmin from "../screens/providers/CompletedBookings";
import PayNow from "../screens/Home/PayNow";

const Stack = createStackNavigator();

function MainNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerTitleStyle: {
          fontWeight: "bold",
          textAlign: "center",
          alignSelf: "center",
          flex: 1,
        },
      }}
      initialRouteName="LoginHome"
    >
      <Stack.Screen name="LoginHome" component={LoginHome} />
      <Stack.Screen
        name="ProvidersRegistration"
        component={ProviderRegistration}
      />
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="ProviderHome" component={ProviderHome} />
      <Stack.Screen name="AddService" component={AddService} />
      <Stack.Screen name="ServiceList" component={ServiceListForProviders} />
      <Stack.Screen name="Search" component={SearchScreen} />
      <Stack.Screen name="Login" component={Login} />
      <Stack.Screen name="LoginUsers" component={LoginUser} />
      <Stack.Screen name="SignUp" component={SignUpMember} />
      <Stack.Screen name="Services" component={SearchItems} />
      <Stack.Screen name="WorkShops" component={ListWorkShops} />
      <Stack.Screen name="ConfirmBooking" component={FinalSubmit} />
      <Stack.Screen name="ConfirmService" component={ConfirmService} />
      <Stack.Screen name="HistoryItems" component={historyAdmin} />

      <Stack.Screen name="PayNow" component={PayNow} />
      {/* PayNow */}
      {/* ConfirmService */}
      {/* FinalSubmit */}
    </Stack.Navigator>
  );
}

const Drawer = createDrawerNavigator();

function DrawerStack() {
  return (
    <Drawer.Navigator
      drawerPosition="left"
      initialRouteName="Main"
      drawerStyle={{
        width: 250,
      }}
      screenOptions={{ headerShown: false }}
      drawerContent={({ navigation }) => (
        <DrawerContainer navigation={navigation} />
      )}
    >
      <Drawer.Screen name="Main" component={MainNavigator} />
    </Drawer.Navigator>
  );
}

export default function AppContainer() {
  return (
    <NavigationContainer>
      <DrawerStack />
    </NavigationContainer>
  );
}

console.disableYellowBox = true;
