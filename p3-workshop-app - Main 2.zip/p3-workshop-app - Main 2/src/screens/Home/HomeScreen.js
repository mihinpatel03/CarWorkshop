import React, { useLayoutEffect, useState, useEffect } from "react";
import {
  FlatList,
  Text,
  View,
  ImageBackground,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { List, Button } from "react-native-paper";

import { useIsFocused } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";

import Icon1 from "react-native-vector-icons/MaterialIcons";

import Icon from "react-native-vector-icons/FontAwesome5";
import { recipes } from "../../data/dataArrays";
import MenuImage from "../../components/MenuImage/MenuImage";
import { BASE_URL } from "../../network/Constants";
import { ScrollView } from "react-native-gesture-handler";

export default function HomeScreen(props) {
  const { navigation } = props;

  const [serviceArray, setServiceArray] = useState([]);

  const isFocused = useIsFocused();

  useLayoutEffect(() => {
    navigation.setOptions({
      headerLeft: () => (
        <MenuImage
          onPress={() => {
            navigation.openDrawer();
          }}
        />
      ),
      headerRight: () => <View />,
    });
  }, []);

  useEffect(() => {
    // alert("");
    if (isFocused) {
      // alert("isFocused");
      getAllBooking();
    }
  }, [isFocused]);

  const getAllBooking = async () => {
    const userId = await AsyncStorage.getItem("@loginId");
    // alert(userId);
    const requestOptions = {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        userId: userId,
      }),
    };
    const response = await fetch(
      BASE_URL + "/listBookingbyUser",
      requestOptions
    )
      .then(async (response) => {
        const isJson = response.headers
          .get("content-type")
          ?.includes("application/json");
        const data = isJson && (await response.json());

        // check for error response
        if (!response.ok) {
          // get error message from body or default to response status
          const error = (data && data.message) || response.status;
          return Promise.reject(error);
        }
        console.log(data);
        if (data) {
          if (data.length == 0) {
            alert("No bookings found.");
          }
          setServiceArray(data);
        } else {
          alert(" Please Retry ");
        }
      })
      .catch((error) => {
        // this.setState({ errorMessage: error.toString() });
        console.error("There was an error!", error);
      });
  };

  const updateStatus = async (isPaid, id) => {
    // const userId = "p@gm";
    // alert("user id= " + userId);

    if (isPaid) {
      alert("Payment Already done");
    } else {
      navigation.navigate("PayNow", { id: id });
    }
  };

  return (
    <View style={styles.container}>
      <ImageBackground
        source={require("../../../assets/serv.jpeg")}
        resizeMode="cover"
        style={styles.image}
      >
        {/* <Text style={styles.text}>Inside</Text> */}

        <Text
          style={{
            backgroundColor: "#5b6e60",
            height: 50,
            fontSize: 17,
            fontWeight: "bold",
            textAlign: "center",
            color: "#fff",
            // marginTop: 3,
          }}
        >
          Current Bookings
        </Text>
        <ScrollView>
          <List.Section title="Services | Your Bookings">
            {serviceArray.map(function (val, index) {
              return (
                <List.Accordion
                  style={{
                    width: 350,
                    backgroundColor: "#fff",
                  }}
                  title={val.workshopName}
                  left={(props) => (
                    <Icon1
                      name="miscellaneous-services"
                      size={20}
                      color="#000"
                    />
                  )}
                  // expanded={true}
                  // onPress={handlePress}
                >
                  <List.Item title={"Service Name : " + val.serviceName} />
                  <List.Item title={"Status : " + val.bookingStatus} />
                  <List.Item title={"Date: " + val.bookingDate} />
                  <List.Item title={"TimeSlot: " + val.bookingSlot} />
                  <View style={{ display: "flex", justifyContent: "center" }}>
                    <Button
                      style={{
                        width: 200,
                        display: "flex",
                        flex: 1,
                        backgroundColor: "#000",
                        // marginBottom: 20,
                        // marginRight: 0,
                      }}
                      onPress={() => updateStatus(val.isPaid, val._id)}
                      mode="outlined"
                      color="#fff"
                      // icon="group"
                      dark={true}
                    >
                      Pay Now
                    </Button>
                  </View>
                </List.Accordion>
              );
            })}
          </List.Section>
        </ScrollView>

        <TouchableOpacity
          style={{
            position: "absolute",
            bottom: 0,
            right: 0,
            paddingRight: 20,
            paddingBottom: 10,
          }}
          onPress={() => navigation.navigate("WorkShops")}
        >
          <Icon name="plus-circle" size={60} color="#000" />
        </TouchableOpacity>
      </ImageBackground>
    </View>
    // </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    flex: 1,
    // justifyContent: "center",
  },
  text: {
    color: "white",
    fontSize: 42,
    lineHeight: 84,
    fontWeight: "bold",
    textAlign: "center",
    backgroundColor: "#000000c0",
  },
});
