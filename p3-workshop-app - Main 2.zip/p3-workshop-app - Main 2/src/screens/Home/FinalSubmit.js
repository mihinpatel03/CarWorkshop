import React, { useState, useEffect } from "react";
import { Button, DataTable, Text, TextInput } from "react-native-paper";

import { useIsFocused } from "@react-navigation/native";
import { View, Picker, StyleSheet, ImageBackground } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { BASE_URL } from "../../network/Constants";

import DateTimePicker from "@react-native-community/datetimepicker";

export default function FinalSubmit({ props, navigation, route }) {
  const [page, setPage] = useState(0);
  const optionsPerPage = [2, 3, 4];
  const [itemsPerPage, setItemsPerPage] = useState(optionsPerPage[0]);
  const [ArrayCarInfo, setArrayCartInfo] = useState([]);
  const [timeSlotArray, setTimeSlotArray] = useState([]);
  const [grandTotalValue, setGrandTotalValue] = useState(0);

  const [timeSlot, setTimeSlot] = useState("");
  const isFocused = useIsFocused();
  //datepicker
  const [bookingDate, setBookingDate] = useState("");
  const [date, setDate] = useState(new Date(1650211822043));
  const [mode, setMode] = useState("date");
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (isFocused) {
      var itemObj = route.params.serviceDetails;
      //   alert("course id" + itemObj.courseName);

      var array = [];
      array.push(itemObj);
      setArrayCartInfo(array);
      setGrandTotalValue(itemObj.price);
      setPage(0);
    }
  }, [props, isFocused, itemsPerPage]);

  const getTimeSlot = async (dateString) => {
    // alert("getTimeSlot");

    // alert(userId);
    const requestOptions = {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        providerId: route.params.workshopId,
      }),
    };
    const response = await fetch(
      BASE_URL + "/checkAvailableTimeSlots",
      requestOptions
    )
      .then(async (response) => {
        const isJson = response.headers
          .get("content-type")
          ?.includes("application/json");
        const data = isJson && (await response.json());

        // check for error response
        if (!response.ok) {
          // get error message from body or default to response status
          const error = (data && data.message) || response.status;
          return Promise.reject(error);
        }
        console.log(data);
        if (data) {
          if (data.length == 0) {
            alert("Slots Available, Please Proceed to book.");
          }
          console.log("bookings array");
          console.log(data);
          var availableSlots = [
            "7amto9am",
            "9amto11am",
            "11amto1pm",
            "2pmto4pm",
            "4pmto6pm",
          ];
          data.forEach((element) => {
            if (element.bookingDate == dateString) {
              if (availableSlots.includes(element.bookingSlot)) {
                // alert("removing time slot:" + element.bookingSlot);
                availableSlots = availableSlots.filter(
                  (e) => e !== element.bookingSlot
                );
              }
            }
          });

          if (availableSlots.length < 1) {
            alert("Sorry There is no time Slot in this Day");
          }
          setTimeSlotArray(availableSlots);
        } else {
          alert(" Please Retry ");
        }
      })
      .catch((error) => {
        // this.setState({ errorMessage: error.toString() });
        console.error("There was an error!", error);
      });

    // <Picker.Item value="4pmto6pm" label="4pmto6pm" />
  };

  const showMode = (currentMode) => {
    setShow(true);
    setMode(currentMode);
  };

  const showDatepicker = () => {
    showMode("date");
  };

  const onDateChange = (event, selectedDate) => {
    // alert("start date" + selectedDate);
    const currentDate = selectedDate || date;
    setShow(Platform.OS === "ios");
    setDate(currentDate);
    console.log("selected date" + currentDate.getDate());
    var dateString =
      currentDate.getDate() +
      "/" +
      Number(currentDate.getMonth() + 1) +
      "/" +
      currentDate.getFullYear();
    //alert(dateString);
    setBookingDate(dateString);
    getTimeSlot(dateString);
  };

  const renderTableRow = ArrayCarInfo.map((item, i) => {
    return (
      <DataTable.Row>
        {/* <DataTable.Cell>{item.cartId}</DataTable.Cell> */}
        <DataTable.Cell> {item.serviceName}</DataTable.Cell>
        {/* <DataTable.Cell> {item.price}</DataTable.Cell> */}
        <DataTable.Cell> {item.description}</DataTable.Cell>
        <DataTable.Cell>{"$ " + item.price}</DataTable.Cell>
      </DataTable.Row>
    );
  });

  function randomId(min, max) {
    // min and max included
    return Math.floor(Math.random() * (max - min + 1) + min);
  }

  const bookConfirmation = async () => {
    alert("Booking In Progress");

    const userId = await AsyncStorage.getItem("@loginId");
    var itemObj = route.params.serviceDetails;
    var workshopName = route.params.workshopName;
    var workshopId = route.params.workshopId;

    if (date == "" || timeSlot == "") {
      alert("Please fill all the values");
      return false;
    }

    //fetch user id wise cart
    const requestOptions = {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },

      body: JSON.stringify({
        user: userId,
        serviceId: itemObj.serviceId,
        serviceName: itemObj.serviceName,
        price: itemObj.price,
        workshopName: workshopName,
        date: bookingDate,
        timeSlot: timeSlot,
        workshopId: workshopId,
      }),
    };
    const response = await fetch(BASE_URL + "/bookService", requestOptions)
      .then(async (response) => {
        const isJson = response.headers
          .get("content-type")
          ?.includes("application/json");
        const data = isJson && (await response.json());

        // check for error response
        if (!response.ok) {
          // get error message from body or default to response status
          const error = (data && data.message) || response.status;
          return Promise.reject(error);
        }
        console.log(data);
        if (data) {
          alert(data);
          alert("Congrats, your Booking Confirmed..");
          navigation.navigate("Home");
        } else {
          alert("No data in the Cart");
        }
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  };

  return (
    <View style={{}}>
      <View style={styles.outercontainer}>
        <ImageBackground
          style={styles.image}
          source={require("../../../assets/service/bg_2.jpeg")}
        >
          <View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "center",
                backgroundColor: "#001a45",
              }}
            >
              <View
                style={{
                  width: 90,
                  marginBottom: 20,
                  marginTop: 10,
                  marginRight: 100,
                }}
              >
                <Text
                  style={{
                    width: 200,
                    marginLeft: 10,
                    marginBottom: 20,
                    color: "#fff",
                  }}
                >
                  Final Booking Confirmation
                </Text>
              </View>
            </View>
            <DataTable
              style={{
                // flexDirection: "row",
                // justifyContent: "center",
                backgroundColor: "#fff",
              }}
            >
              <DataTable.Header>
                <DataTable.Title>Service</DataTable.Title>
                <DataTable.Title>Description</DataTable.Title>
                {/* <DataTable.Title>Duration</DataTable.Title> */}
                <DataTable.Title>Total</DataTable.Title>
              </DataTable.Header>
              {renderTableRow}
            </DataTable>

            <Button
              //   style={{ width: 250, marginBottom: 20 }}
              style={{
                width: 200,
                height: 40,
                // marginBottom: 20,
                marginTop: 10,
                marginLeft: 170,
                backgroundColor: "#fff",
              }}
              mode="outlined"
              dark={true}
              onPress={() => showDatepicker()}
            >
              <Text>Pick A Date</Text>
            </Button>
            {show && (
              <DateTimePicker
                testID="dateTimePicker"
                value={date}
                mode={mode}
                is24Hour={true}
                display="default"
                onChange={onDateChange}
              />
            )}
            <Text
              style={{
                width: 200,
                // height: 40,
                // marginBottom: 20,
                // marginTop: 10,
                marginLeft: 170,
                backgroundColor: "#fff",
              }}
            >
              {bookingDate}
            </Text>
            <Text
              style={{
                width: 200,
                // height: 40,
                // marginBottom: 20,
                marginTop: 10,
                marginLeft: 170,
                backgroundColor: "#fff",
              }}
            >
              Select Time Slot
            </Text>
            <View
              style={{
                width: 200,
                height: 40,
                marginBottom: 20,
                // marginTop: 10,
                marginLeft: 170,
                backgroundColor: "#fff",
              }}
            >
              <Picker
                selectedValue={timeSlot}
                // style={{ height: 50, width: "69%" }}
                onValueChange={(itemValue, itemIndex) => setTimeSlot(itemValue)}
                style={{ height: 50, width: 185 }}
              >
                {timeSlotArray.map(function (val, index) {
                  return <Picker.Item value={val} label={val} />;
                })}
              </Picker>
            </View>

            <TextInput
              style={{
                width: 200,
                height: 40,
                marginBottom: 20,
                marginLeft: 170,
              }}
              editable={false}
            >
              Pay Total $: {grandTotalValue}
            </TextInput>

            <Button
              style={{
                width: 200,
                marginLeft: 170,
                marginBottom: 20,
                borderColor: "#000",
                backgroundColor: "#001a45",
              }}
              color="#fff"
              mode="outlined"
              dark={true}
              onPress={() => bookConfirmation()}
            >
              CONFIRM
            </Button>
          </View>
        </ImageBackground>
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  outercontainer: {
    width: "100%",
    height: "100%",
    backgroundColor: "#011f4f",
    alignItems: "center",
  },
  container: {
    width: "80%",
    height: "70%",
    alignItems: "flex-end",
    justifyContent: "flex-end",
  },

  image: {
    width: "100%",
    height: "100%",
  },

  logo: {
    width: "70%",
    height: "30%",
    marginBottom: 40,
  },

  inputView: {
    backgroundColor: "#000",
    borderRadius: 30,
    width: "100%",
    height: 45,
    marginBottom: 20,

    alignItems: "center",
  },

  TextInput: {
    height: 50,
    flex: 1,
    padding: 15,

    color: "#fff",
  },

  forgot_button: {
    height: 30,
    width: "40%",
    // padding: 15,
    marginTop: 30,
    // backgroundColor: "#bdb4b3",
    borderRadius: 15,
  },

  loginBtn: {
    width: "75%",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 20,
    marginBottom: 40,

    backgroundColor: "#001670",
  },
  registerBtn: {
    width: "40%",
    borderRadius: 10,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    marginLeft: 0,
    backgroundColor: "#f5eeed",
  },
});
