import React, { useEffect, useState } from "react";
import {
  Headline,
  TextInput,
  Text,
  Card,
  Title,
  List,
  Paragraph,
  Button,
  BottomNavigation,
  Checkbox,
} from "react-native-paper";
import { View, ScrollView, ImageBackground, StyleSheet } from "react-native";
import { useIsFocused } from "@react-navigation/native";

import Icon from "react-native-vector-icons/MaterialIcons";
import { BASE_URL } from "../../network/Constants";
// import { ScrollView } from "react-native-gesture-handler";

export default function SearchItems({ navigation, route }) {
  const [expanded, setExpanded] = React.useState(false);

  const [overAllAmount, setOverAllAmount] = useState("");
  const isFocused = useIsFocused();
  const [serviceArray, setServiceArray] = useState([]);

  const handlePress = () => setExpanded(!expanded);

  useEffect(() => {
    if (isFocused) {
      getAllServices();
    }
  }, [isFocused]);

  const getAllServices = async () => {
    var providerId = route.params.providerId;
    // alert(providerId);
    const requestOptions = {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        providerId: providerId,
      }),
    };
    const response = await fetch(
      BASE_URL + "/listServicesProvider",
      requestOptions
    )
      .then(async (response) => {
        const isJson = response.headers
          .get("content-type")
          ?.includes("application/json");
        const data = isJson && (await response.json());

        // check for error response
        if (!response.ok) {
          // get error message from body or default to response status
          const error = (data && data.message) || response.status;
          return Promise.reject(error);
        }
        console.log(data);
        if (data) {
          if (data.length == 0) {
            alert("No services found, Please check other workshops.");
          }
          setServiceArray(data);
        } else {
          alert(" Please Retry ");
        }
      })
      .catch((error) => {
        // this.setState({ errorMessage: error.toString() });
        console.error("There was an error!", error);
      });
  };

  return (
    <ScrollView style={styles.container}>
      <ImageBackground
        source={require("../../../assets/serv.jpeg")}
        resizeMode="cover"
        style={styles.image}
      >
        {/* <Title
          style={{
            marginBottom: 30,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          Available Services
        </Title> */}

        <List.Section title="Services | By Providers">
          {serviceArray.map(function (val, index) {
            return (
              <List.Accordion
                style={{
                  width: 350,
                  backgroundColor: "#fff",
                }}
                title={val.serviceName}
                left={(props) => (
                  <Icon name="miscellaneous-services" size={20} color="#000" />
                )}
                // expanded={expanded}
                onPress={handlePress}
              >
                <List.Item title={"Cost : $" + val.price} />
                <List.Item title={"Description: " + val.description} />
                <View style={{ display: "flex", justifyContent: "center" }}>
                  <Button
                    style={{
                      width: 100,
                      display: "flex",
                      flex: 1,

                      backgroundColor: "#000",
                      // marginBottom: 20,
                      // marginRight: 0,
                    }}
                    onPress={() =>
                      navigation.navigate("ConfirmBooking", {
                        serviceDetails: val,
                        workshopName: route.params.workshopName,
                        workshopId: route.params.providerId,
                      })
                    }
                    mode="outlined"
                    color="#fff"
                    // icon="group"
                    dark={true}
                  >
                    Book
                  </Button>
                </View>
              </List.Accordion>
            );
          })}
        </List.Section>
      </ImageBackground>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    flex: 1,
    // justifyContent: "center",
  },
  text: {
    color: "white",
    fontSize: 42,
    lineHeight: 84,
    fontWeight: "bold",
    textAlign: "center",
    backgroundColor: "#000000c0",
  },
});
