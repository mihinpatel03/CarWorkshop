import React, { useEffect, useState } from "react";
import {
  Headline,
  TextInput,
  Text,
  Card,
  Title,
  List,
  Paragraph,
  Button,
  BottomNavigation,
  Checkbox,
  Searchbar,
} from "react-native-paper";
import { View, ScrollView, ImageBackground, StyleSheet } from "react-native";
import { useIsFocused } from "@react-navigation/native";

import Icon from "react-native-vector-icons/MaterialIcons";
import { BASE_URL } from "../../network/Constants";
// import { ScrollView } from "react-native-gesture-handler";

export default function ListWorkShops({ navigation, route }) {
  const [expanded, setExpanded] = React.useState(false);

  const [overAllAmount, setOverAllAmount] = useState("");
  const isFocused = useIsFocused();
  const [serviceArray, setServiceArray] = useState([]);

  const handlePress = () => setExpanded(!expanded);

  const [searchQuery, setSearchQuery] = React.useState("");
  const onChangeSearch = (query) => setSearchQuery(query);

  const onSearch = () => {
    if (searchQuery == "") {
      getAllServices();
    } else {
      let obj = serviceArray.find((o) =>
        o.workshopAddress.includes(searchQuery)
      );
      // alert("Great..! Found Workshops... ");
      console.log(obj);
      var arr = [];
      arr.push(obj);
      setServiceArray(arr);
      // setSearchQuery("");
    }
  };

  useEffect(() => {
    if (isFocused) {
      getAllServices();
    }
  }, [isFocused]);

  const getAllServices = async () => {
    const requestOptions = {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        userId: "",
      }),
    };
    const response = await fetch(BASE_URL + "/listWorkshops", requestOptions)
      .then(async (response) => {
        const isJson = response.headers
          .get("content-type")
          ?.includes("application/json");
        const data = isJson && (await response.json());

        // check for error response
        if (!response.ok) {
          // get error message from body or default to response status
          const error = (data && data.message) || response.status;
          return Promise.reject(error);
        }
        console.log(data);
        if (data) {
          setServiceArray(data);
        } else {
          alert(" Please Retry ");
        }
      })
      .catch((error) => {
        // this.setState({ errorMessage: error.toString() });
        console.error("There was an error!", error);
      });
  };

  return (
    <ScrollView style={styles.container}>
      <ImageBackground
        source={require("../../../assets/serv.jpeg")}
        resizeMode="cover"
        style={styles.image}
      >
        <Searchbar
          placeholder="Search Location"
          onChangeText={onChangeSearch}
          value={searchQuery}
          style={{ marginTop: 10 }}
          onIconPress={() => onSearch()}
          onTouchCancel={() => searchQuery("")}
        />
        <List.Section title="Available Workshops">
          {serviceArray.map(function (val, index) {
            return (
              <List.Accordion
                style={{
                  width: 350,
                  backgroundColor: "#fff",
                }}
                title={val.workshopName}
                left={(props) => (
                  <Icon name="miscellaneous-services" size={20} color="#000" />
                )}
                // expanded={expanded}
                onPress={handlePress}
              >
                <List.Item title={"Contact : " + val.contactNumber} />
                <List.Item title={"Address: " + val.workshopAddress} />

                <View style={{ display: "flex", justifyContent: "center" }}>
                  <Button
                    style={{
                      width: 200,
                      display: "flex",
                      flex: 1,

                      backgroundColor: "#000",
                      // marginBottom: 20,
                      // marginRight: 0,
                    }}
                    onPress={() =>
                      navigation.navigate("Services", {
                        providerId: val.email,
                        workshopName: val.workshopName,
                      })
                    }
                    mode="outlined"
                    color="#fff"
                    // icon="group"
                    dark={true}
                  >
                    View Services
                  </Button>
                </View>
              </List.Accordion>
            );
          })}
        </List.Section>
      </ImageBackground>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    flex: 1,
    // justifyContent: "center",
  },
  text: {
    color: "white",
    fontSize: 42,
    lineHeight: 84,
    fontWeight: "bold",
    textAlign: "center",
    backgroundColor: "#000000c0",
  },
});
