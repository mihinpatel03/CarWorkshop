import React, { useState, useEffect } from "react";
import { Button, DataTable, Text, TextInput } from "react-native-paper";
import { useIsFocused } from "@react-navigation/native";
import { View, Picker, StyleSheet, ImageBackground } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { BASE_URL } from "../../network/Constants";
import DateTimePicker from "@react-native-community/datetimepicker";

export default function PayNow({ props, navigation, route }) {
  //   useEffect(() => {
  //     if (isFocused) {
  //       var itemObj = route.params.id;
  //     }
  //   }, [props, isFocused, itemsPerPage]);

  const conifrmPayment = async () => {
    // const userId = "p@gm";
    alert("Your Payment is in Progress");
    var id = route.params.id;

    const requestOptions = {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        id: id,
        isPaid: true,
      }),
    };
    const response = await fetch(BASE_URL + "/payment", requestOptions)
      .then(async (response) => {
        const isJson = response.headers
          .get("content-type")
          ?.includes("application/json");
        const data = isJson && (await response.json());

        // check for error response
        if (!response.ok) {
          // get error message from body or default to response status
          const error = (data && data.message) || response.status;
          return Promise.reject(error);
        }
        console.log(data);
        if (data) {
          alert("Payment Successful");
          navigation.navigate("Home");
          //alert("Success: Retrieved ");
        } else {
          alert("No orders yet");
        }
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  };

  return (
    <View style={{}}>
      <View style={styles.outercontainer}>
        <ImageBackground
          style={styles.image}
          source={require("../../../assets/payment.jpg")}
        >
          <View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "center",
                backgroundColor: "#001a45",
              }}
            >
              <View
                style={{
                  width: 90,
                  marginBottom: 20,
                  marginTop: 10,
                  marginRight: 100,
                }}
              >
                <Text
                  style={{
                    width: 300,
                    // marginLeft: 5,
                    marginBottom: 20,
                    color: "#fff",
                  }}
                >
                  Gateway Partners | Paytm | GPay
                </Text>
                <Text
                  style={{
                    width: 200,
                    marginLeft: 10,
                    marginBottom: 20,
                    color: "#fff",
                  }}
                >
                  Click the Below Button to Pay....
                </Text>
              </View>
            </View>

            <Button
              //   style={{ width: 250, marginBottom: 20 }}
              style={{
                width: 300,
                height: 40,
                // marginBottom: 20,
                marginTop: 200,
                marginLeft: 50,
                backgroundColor: "#000",
              }}
              mode="outlined"
              dark={true}
              onPress={() => conifrmPayment()}
            >
              <Text style={{ color: "#fff" }}>Pay Now</Text>
            </Button>
          </View>
        </ImageBackground>
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  outercontainer: {
    width: "100%",
    height: "100%",
    backgroundColor: "#011f4f",
    alignItems: "center",
    display: "flex",
  },
  container: {
    width: "80%",
    height: "70%",
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
  },

  image: {
    width: "100%",
    height: "100%",
  },

  logo: {
    width: "70%",
    height: "30%",
    marginBottom: 40,
  },

  inputView: {
    backgroundColor: "#000",
    borderRadius: 30,
    width: "100%",
    height: 45,
    marginBottom: 20,

    alignItems: "center",
  },

  TextInput: {
    height: 50,
    flex: 1,
    padding: 15,

    color: "#fff",
  },

  forgot_button: {
    height: 30,
    width: "40%",
    // padding: 15,
    marginTop: 30,
    // backgroundColor: "#bdb4b3",
    borderRadius: 15,
  },

  loginBtn: {
    width: "75%",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 20,
    marginBottom: 40,

    backgroundColor: "#001670",
  },
  registerBtn: {
    width: "40%",
    borderRadius: 10,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    marginLeft: 0,
    backgroundColor: "#f5eeed",
  },
});
