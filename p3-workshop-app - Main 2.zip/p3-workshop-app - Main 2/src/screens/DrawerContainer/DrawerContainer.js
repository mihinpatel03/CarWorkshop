import React from "react";
import { View } from "react-native";
import PropTypes from "prop-types";
import styles from "./styles";
import MenuButton from "../../components/MenuButton/MenuButton";
import Icon from "react-native-vector-icons/SimpleLineIcons";

import AsyncStorage from "@react-native-async-storage/async-storage";

export default function DrawerContainer(props) {
  const { navigation } = props;
  console.disableYellowBox = true;
  const SignOut = async (navigation) => {
    // alert("signOut");
    await AsyncStorage.removeItem("@loginId");
    navigation.closeDrawer();
    navigation.navigate("Login");
  };
  return (
    <View style={styles.content}>
      <View style={styles.container}>
        <MenuButton
          title="HOME"
          source={require("../../../assets/icons/home.png")}
          onPress={() => {
            navigation.navigate("LoginHome");
            navigation.closeDrawer();
          }}
        />

        {/* <MenuButton
          title="SEARCH"
          source={require("../../../assets/icons/search.png")}
          onPress={() => {
            // navigation.navigate("Search");
            alert("Todo");
            navigation.closeDrawer();
          }}
        /> */}

        <MenuButton
          title="LogOut"
          source={require("../../../assets/icons/sign-out-alt.png")}
          onPress={() => {
            SignOut(navigation);
          }}
        />
      </View>
    </View>
  );
}

DrawerContainer.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired,
  }),
};
