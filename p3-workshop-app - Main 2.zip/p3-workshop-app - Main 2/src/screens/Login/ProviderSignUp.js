import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  TouchableOpacity,
} from "react-native";
import { Dialog, Portal, Provider, Button } from "react-native-paper";
import Icon from "react-native-vector-icons/MaterialIcons";
import { BASE_URL } from "../../network/Constants";

export default function ProviderRegistration({ navigation }) {
  const [email, setEmail] = useState("");
  const [isEmailVerified, setIsEmailVerified] = useState(false);
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [workshopName, setWorkshopName] = useState("");
  const [workshopAddress, setWorkshopAddress] = useState("");
  const [mobNo, setMobNo] = useState("");

  //verification dialog
  const [otp, setOtp] = useState("");
  const [visible, setVisible] = React.useState(false);
  const showDialog = () => {
    setVisible(true);
  };
  const hideDialog = () => setVisible(false);

  const verifyEmail = () => {
    var arr = ["1234", "2222", "3344", "4545", "1254"];
    if (arr.includes(otp) && email != "") {
      alert("Email Verified, Thanks");
      setIsEmailVerified(true);
      setVisible(false);
    } else {
      alert("Please enter the valid OTP");
    }
  };

  const addUser = async () => {
    console.log("user");
    console.log("user async ");
    if (
      email == "" ||
      password == "" ||
      name == "" ||
      isEmailVerified == false
    ) {
      alert("Verify Email and Please enter all the values, and retry.");
    } else {
      alert("reached");
      const requestOptions = {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email,
          name: name,
          password: password,
          workshopAddress: workshopAddress,
          workshopName: workshopName,
          contactNumber: mobNo,
        }),
      };
      const response = await fetch(BASE_URL + "/signupprovider", requestOptions)
        .then(async (response) => {
          const isJson = response.headers
            .get("content-type")
            ?.includes("application/json");
          const data = isJson && (await response.json());

          // check for error response
          if (!response.ok) {
            // get error message from body or default to response status
            const error = (data && data.message) || response.status;
            return Promise.reject(error);
          }

          console.log("success");
          alert("Successfully Created the Provider");
          navigation.navigate("Login");
        })
        .catch((error) => {
          // this.setState({ errorMessage: error.toString() });
          console.error("There was an error!", error);
        });
    }
  };

  return (
    <View style={styles.container}>
      <Icon name="miscellaneous-services" size={80} color="#900" />
      <View style={{ marginTop: 10, marginBottom: 10 }}></View>
      <View style={styles.inputView}>
        <TextInput
          style={styles.TextInput}
          placeholder="Enter Name"
        
          placeholderTextColor="#000"
          onChangeText={(userName) => setName(userName)}
        />
      </View>
      <View style={styles.inputView}>
        <TextInput
          style={styles.TextInput}
          placeholder="Enter Email"
          placeholderTextColor="#000"
          onChangeText={(userName) => setEmail(userName)}
        />
      </View>
      <Button
        style={{
          borderRadius: 25,
          height: 30,
          alignItems: "center",
          justifyContent: "center",
          marginBottom: 20,
          color:"#fff",
          backgroundColor: "#000",
        }}
        onPress={() => showDialog()}
      >
        Verify Email
      </Button>
      <View style={styles.inputView}>
        <TextInput
          style={styles.TextInput}
          placeholder="Password"
          placeholderTextColor="#000"
          secureTextEntry={true}
          onChangeText={(userName) => setPassword(userName)}
        />
      </View>
      <View style={styles.inputView}>
        <TextInput
          style={styles.TextInput}
          placeholder="Enter Workshop Name"
          placeholderTextColor="#000"
          onChangeText={(userName) => setWorkshopName(userName)}
        />
      </View>
      <View style={styles.inputView}>
        <TextInput
          style={styles.TextInput}
          placeholder="Enter Mob Number"
          placeholderTextColor="#000"
          onChangeText={(userName) => setMobNo(userName)}
        />
      </View>
      <View style={styles.inputView}>
        <TextInput
          style={styles.TextInput}
          placeholder="Enter Workshop Address"
          placeholderTextColor="#000"
          onChangeText={(userName) => setWorkshopAddress(userName)}
        />
      </View>

      <TouchableOpacity style={styles.loginBtn} onPress={() => addUser()}>
        <Text style={{ color: "#fff" }}>Register</Text>
      </TouchableOpacity>

      <Provider>
        <View>
          <Portal>
            <Dialog visible={visible} onDismiss={hideDialog}>
              <Dialog.Title>Alert</Dialog.Title>
              <Dialog.Content>
                <View
                  style={{
                    backgroundColor: "#fff",
                    borderRadius: 30,
                    width: "70%",
                    height: 45,
                    // marginBottom: 20,
                    alignItems: "center",
                  }}
                >
                  <TextInput
                    style={styles.AlertTextInput}
                    placeholder="Enter the Email OTP"
                    placeholderTextColor="#000"
                    onChangeText={(userName) => setOtp(userName)}
                  />
                </View>
              </Dialog.Content>
              <Dialog.Actions>
                <Button
                 style={{
                  borderRadius: 25,
                  height: 30,
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: 20,
                  color:"#fff",
                  backgroundColor: "#000",
                }}
                
                onPress={() => verifyEmail()}>Verify</Button>
              </Dialog.Actions>
            </Dialog>
          </Portal>
        </View>
      </Provider>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },

  image: {
    marginBottom: 40,
  },

  inputView: {
    backgroundColor: "#fff",
    borderRadius: 30,
    width: "70%",
    height: 45,
    marginBottom: 20,
borderColor:"#000",
borderWidth: 2,
    alignItems: "flex-start",
  },

  TextInput: {
    height: 50,
    flex: 1,
    padding: 10,
    marginLeft: 20,
    color: "#000",
  },
  AlertTextInput: {
    height: 50,
    flex: 1,
    padding: 10,
    borderRadius: 20,
    marginLeft: 20,
    borderColor:"#000",
borderWidth: 2,
    color: "#000",
  },

  forgot_button: {
    height: 30,
    width: "40%",
    // padding: 15,
    marginTop: 30,
    // backgroundColor: "#bdb4b3",
    borderRadius: 15,
  },

  loginBtn: {
    width: "75%",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 20,
    marginBottom: 40,
  
    color:"#FFF",
    backgroundColor: "#29395E",
  },
  registerBtn: {
    width: "40%",
    borderRadius: 10,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    marginLeft: 0,
    backgroundColor: "#f5eeed",
  },
});