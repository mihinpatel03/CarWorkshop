// import { StatusBar } from "expo-status-bar";
import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  Button,
  TouchableOpacity,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { BASE_URL } from "../../network/Constants";
import Icon from "react-native-vector-icons/Feather";

export default function LoginUser({ navigation }) {
  const [userName, setuserName] = useState("");
  const [password, setPassword] = useState("");

  const LoginFlow = async () => {
   loginForUsers();
    // navigation.navigate("Home", {
    //   loginId: "userName",
    // });
  };
  const loginForProviders = async () => {
    // alert("reached");
    const requestOptions = {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: userName,
        password: password,
        isProvider: true,
      }),
    };
    const response = await fetch(BASE_URL + "/login", requestOptions)
      .then(async (response) => {
        const isJson = response.headers
          .get("content-type")
          ?.includes("application/json");
        const data = isJson && (await response.json());

        // check for error response
        if (!response.ok) {
          // get error message from body or default to response status
          const error = (data && data.message) || response.status;
          return Promise.reject(error);
        }

        if (data) {
          alert("Login Success");

          await AsyncStorage.setItem("@loginId", userName);
          navigation.navigate("ProviderHome", {
            loginId: userName,
          });
          // navigation.navigate("Home");
        } else {
          alert("Please retry.. Credentials Invalid or Network Error");
        }
      })
      .catch((error) => {
        // this.setState({ errorMessage: error.toString() });
        console.error("There was an error!", error);
      });
  };

  const loginForUsers = async () => {
    // alert("reached");
    const requestOptions = {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: userName,
        password: password,
        isProvider: false,
      }),
    };
    const response = await fetch(BASE_URL + "/login", requestOptions)
      .then(async (response) => {
        const isJson = response.headers
          .get("content-type")
          ?.includes("application/json");
        const data = isJson && (await response.json());

        // check for error response
        if (!response.ok) {
          // get error message from body or default to response status
          const error = (data && data.message) || response.status;
          return Promise.reject(error);
        }

        if (data) {
          alert("Login Success");

          await AsyncStorage.setItem("@loginId", userName);
          navigation.navigate("Home", {
            loginId: userName,
          });
          // navigation.navigate("Home");
        } else {
          alert("Please retry.. Credentials Invalid or Network Error");
        }
      })
      .catch((error) => {
        this.setState({ errorMessage: error.toString() });
        console.error("There was an error!", error);
      });
  };

  return (
    <View style={styles.container}>
      {/* <Image style={styles.image} source={require("./assets/tutor.png")} /> */}

      {/* <StatusBar style="auto" /> */}
      <View style={styles.inputView}>
        <TextInput
          style={styles.TextInput}
          placeholder="Email"
          placeholderTextColor="#000"
          onChangeText={(userName) => setuserName(userName)}
        />
      </View>

      <View style={styles.inputView}>
        <TextInput
          style={styles.TextInput}
          placeholder="Password"
          placeholderTextColor="#000"
          secureTextEntry={true}
          onChangeText={(password) => setPassword(password)}
        />
      </View>

      <TouchableOpacity style={styles.loginBtn} onPress={() => LoginFlow()}>
        <Text style={{ color: "#fff" }}>LOGIN</Text>
      </TouchableOpacity>

      {/* <Icon.Button
        name="plus"
        backgroundColor="#fff"
        color="#000"
        onPress={() => navigation.navigate("SignUp")}
      >
        <Text style={{ fontFamily: "Arial", fontSize: 15, color: "#000" }}>
          User Registration
        </Text>
      </Icon.Button> */}

      <Icon.Button
        name="user"
        backgroundColor="#29395E"
        color="#FFF"
        onPress={() => navigation.navigate("SignUp")}
      >
        <Text style={{ fontFamily: "Arial", fontSize: 15, color: "#fff" }}>
          Users Registration
        </Text>
      </Icon.Button>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFF",
    alignItems: "center",
    justifyContent: "center",
  },

  image: {
    marginBottom: 40,
  },

  inputView: {
    backgroundColor: "#fff",
    borderRadius: 30,
    width: "70%",
    height: 45,
    marginBottom: 20,
borderColor:"#000",
borderWidth: 2,
    alignItems: "flex-start",
  },

  TextInput: {
    height: 50,
    flex: 1,
    padding: 10,
    marginLeft: 20,
    color: "#000",
  },

  forgot_button: {
    height: 30,
    width: "40%",
    // padding: 15,
    marginTop: 30,
    // backgroundColor: "#bdb4b3",
    borderRadius: 15,
  },

  loginBtn: {
    width: "75%",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 20,
    marginBottom: 40,

    backgroundColor: "#7a0800",
  },
  registerBtn: {
    width: "40%",
    borderRadius: 10,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    marginLeft: 0,
    backgroundColor: "#f5eeed",
  },
});
