// import { StatusBar } from "expo-status-bar";
import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  Button,
  ImageBackground,
  TouchableOpacity,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { BASE_URL } from "../../network/Constants";
import Icon from "react-native-vector-icons/MaterialIcons";

import IconFe from "react-native-vector-icons/Feather";

export default function LoginHome({ navigation }) {
  return (
    <View style={styles.outercontainer}>
      <ImageBackground
        style={styles.image}
        source={require("../../../assets/service/bg_2.jpeg")}
     
>
<View style={styles.container}>
{/* <Image
        style={styles.logo}
        source={require("../../../assets/service/logo.jpeg")}
      /> */}
      <IconFe.Button
        name="users"
        backgroundColor="#29395E"
        color="#FFF"
        onPress={() => navigation.navigate("LoginUsers")}
      >
        <Text
          style={{
            fontFamily: "Arial",
            fontSize: 20,
            color: "#FFF",
            width: 180,
          }}
        >
          Users
        </Text>
      </IconFe.Button>
      <View style={{ marginTop: 10, marginBottom: 10 }}></View>
      <Icon.Button
        name="miscellaneous-services"
        backgroundColor="#29395E"
        color="#FFF"
        onPress={() => navigation.navigate("Login")}
      >
        <Text
          style={{
            fontFamily: "Arial",
            fontSize: 20,
            color: "#FFF",
            width: 180,
          }}
        >
          Service Providers
        </Text>
      </Icon.Button>
      </View>
     
      </ImageBackground>
    </View>
  );
}

const styles = StyleSheet.create({
  outercontainer: {
    width: "100%",
    height: "100%",
    backgroundColor: "#011f4f",
    alignItems: "center",
  
   
   
  },
  container: {

    width: "80%",
    height: "70%",
    alignItems: "flex-end",
    justifyContent: "flex-end",
  },

  image: {
    width: "100%",
    height: "100%"
  },

  logo: {
   width: "70%",
   height:"30%",
    marginBottom: 40
  },

  inputView: {
    backgroundColor: "#000",
    borderRadius: 30,
    width: "100%",
    height: 45,
    marginBottom: 20,

    alignItems: "center",
  },

  TextInput: {
    height: 50,
    flex: 1,
    padding: 15,

    color: "#fff",
  },

  forgot_button: {
    height: 30,
    width: "40%",
    // padding: 15,
    marginTop: 30,
    // backgroundColor: "#bdb4b3",
    borderRadius: 15,
  },

  loginBtn: {
    width: "75%",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 20,
    marginBottom: 40,

    backgroundColor: "#001670",
  },
  registerBtn: {
    width: "40%",
    borderRadius: 10,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    marginLeft: 0,
    backgroundColor: "#f5eeed",
  },
});
