// import { StatusBar } from "expo-status-bar";
import React, { useLayoutEffect, useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  Button,
  TouchableOpacity,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { BASE_URL } from "../../network/Constants";
import Icon from "react-native-vector-icons/MaterialIcons";

import MenuImage from "../../components/MenuImage/MenuImage";
import IconFe from "react-native-vector-icons/Feather";

export default function ProviderHome({ navigation }) {
  // const { navigation } = props;

  useLayoutEffect(() => {
    navigation.setOptions({
      headerLeft: () => (
        <MenuImage
          onPress={() => {
            navigation.openDrawer();
          }}
        />
      ),
      headerRight: () => <View />,
    });
  }, []);

  return (
    <View style={styles.container}>
      {/* <Image
        style={styles.image}
        source={require("../../../assets/service/serviceIcon.png")}
      /> */}

      <Icon name="admin-panel-settings" size={80} color="#ff8084" />
      <View style={{ marginTop: 10, marginBottom: 10 }}></View>
      <IconFe.Button
        name="plus"
        backgroundColor="#fff"
        color="#000"
        onPress={() => navigation.navigate("AddService")}
      >
        <Text
          style={{
            fontFamily: "Arial",
            fontSize: 15,
            color: "#000",
            width: 120,
          }}
        >
          Add Service
        </Text>
      </IconFe.Button>

      <View style={{ marginTop: 10, marginBottom: 10 }}></View>
      <Icon.Button
        name="miscellaneous-services"
        backgroundColor="#fff"
        color="#000"
        onPress={() => navigation.navigate("ServiceList")}
      >
        <Text
          style={{
            fontFamily: "Arial",
            fontSize: 15,
            color: "#000",
            width: 120,
          }}
        >
          List Service
        </Text>
      </Icon.Button>

      <View style={{ marginTop: 10, marginBottom: 10 }}></View>
      <Icon.Button
        name="bookmark-outline"
        backgroundColor="#fff"
        color="#000"
        onPress={() => navigation.navigate("ConfirmService")}
      >
        <Text
          style={{
            fontFamily: "Arial",
            fontSize: 15,
            color: "#000",
            width: 120,
          }}
        >
          Orders
        </Text>
      </Icon.Button>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#011f4f",
    alignItems: "center",
    justifyContent: "center",
  },

  image: {
    marginBottom: 40,
  },

  inputView: {
    backgroundColor: "#000",
    borderRadius: 30,
    width: "70%",
    height: 45,
    marginBottom: 20,

    alignItems: "center",
  },

  TextInput: {
    height: 50,
    flex: 1,
    padding: 10,
    marginLeft: 20,
    color: "#fff",
  },

  forgot_button: {
    height: 30,
    width: "40%",
    // padding: 15,
    marginTop: 30,
    // backgroundColor: "#bdb4b3",
    borderRadius: 15,
  },

  loginBtn: {
    width: "75%",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 20,
    marginBottom: 40,

    backgroundColor: "#001670",
  },
  registerBtn: {
    width: "40%",
    borderRadius: 10,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    marginLeft: 0,
    backgroundColor: "#f5eeed",
  },
});
