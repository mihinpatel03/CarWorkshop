import React, { useState, useEffect, useLayoutEffect } from "react";
import { Button, DataTable } from "react-native-paper";
import { useIsFocused } from "@react-navigation/native";
import { View } from "react-native";
import { BASE_URL } from "../../network/Constants";
import MenuImage from "../../components/MenuImage/MenuImage";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function ServiceListForProviders({ props, navigation }) {
  const [page, setPage] = useState(0);
  const optionsPerPage = [2, 3, 4];
  const [itemsPerPage, setItemsPerPage] = useState(optionsPerPage[0]);
  const [ServiceList, setServiceList] = useState([]);
  const isFocused = useIsFocused();
  useLayoutEffect(() => {
    navigation.setOptions({
      headerLeft: () => (
        <MenuImage
          onPress={() => {
            navigation.openDrawer();
          }}
        />
      ),
      headerRight: () => <View />,
    });
  }, []);

  useEffect(() => {
    if (isFocused) {
      getServiceList();
      setPage(0);
    }
  }, [props, isFocused, itemsPerPage]);

  const renderTableRow = ServiceList.map((item, i) => {
    return (
      <DataTable.Row>
        <DataTable.Cell>{item.serviceId}</DataTable.Cell>
        <DataTable.Cell> {item.serviceName}</DataTable.Cell>
        <DataTable.Cell> {item.price}</DataTable.Cell>
        <DataTable.Cell>
          <Button
            // style={{ width: 100, marginBottom: 30 }}
            mode="outlined"
            // onPress={() => deleteDoc(item.serviceId)}
          >
            X
          </Button>
        </DataTable.Cell>
      </DataTable.Row>
    );
  });

  const deleteDoc = async (prodId) => {
    const requestOptions = {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        categoryId: prodId,
      }),
    };
    const response = await fetch(BASE_URL + "/deleteCategory", requestOptions)
      .then(async (response) => {
        const isJson = response.headers
          .get("content-type")
          ?.includes("application/json");
        const data = isJson && (await response.json());

        // check for error response
        if (!response.ok) {
          // get error message from body or default to response status
          const error = (data && data.message) || response.status;
          return Promise.reject(error);
        }
        console.log(data);
        if (data) {
          alert("deleted the category");
          getServiceList();
          //alert("Success: Retrieved ");
        } else {
          alert(" Please Retry ");
        }
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });

    //
  };

  const getServiceList = async () => {
    var arrayProjects = [];
    const userId = await AsyncStorage.getItem("@loginId");
    const requestOptions = {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        providerId: userId,
      }),
    };
    const response = await fetch(
      BASE_URL + "/listServicesProvider",
      requestOptions
    )
      .then(async (response) => {
        const isJson = response.headers
          .get("content-type")
          ?.includes("application/json");
        const data = isJson && (await response.json());

        // check for error response
        if (!response.ok) {
          // get error message from body or default to response status
          const error = (data && data.message) || response.status;
          return Promise.reject(error);
        }
        console.log(data);
        if (data) {
          setServiceList(data);
          console.log("success");
          //alert("Success: Retrieved ");
        } else {
          alert(" Please Retry ");
        }
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  };

  return (
    <View style={{}}>
      <DataTable>
        <DataTable.Header>
          <DataTable.Title style={{ color: "#fff" }}>ID</DataTable.Title>
          <DataTable.Title>Service</DataTable.Title>
          <DataTable.Title>Price</DataTable.Title>
          {/* <DataTable.Title>Edit</DataTable.Title> */}
          <DataTable.Title>Delete</DataTable.Title>
        </DataTable.Header>
        {renderTableRow}

        {/* <DataTable.Pagination
          page={page}
          numberOfPages={3}
          onPageChange={(page) => setPage(page)}
          label="1-2 of 6"
          optionsPerPage={optionsPerPage}
          itemsPerPage={itemsPerPage}
          setItemsPerPage={setItemsPerPage}
          showFastPagination
          optionsLabel={"Rows per page"}
        /> */}
      </DataTable>
    </View>
  );
}
