// import { StatusBar } from "expo-status-bar";
import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  Button,
  TouchableOpacity,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { BASE_URL } from "../../network/Constants";
import Icon from "react-native-vector-icons/MaterialIcons";

export default function AddService({ navigation }) {
  const [serviceName, setServiceName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState(0);

  const addService = async () => {
    // alert("reached");
    const userId = await AsyncStorage.getItem("@loginId");
    const requestOptions = {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        serviceName: serviceName,
        description: description,
        price: price,
        providerId: userId,
      }),
    };
    const response = await fetch(BASE_URL + "/addservice", requestOptions)
      .then(async (response) => {
        const isJson = response.headers
          .get("content-type")
          ?.includes("application/json");
        const data = isJson && (await response.json());

        // check for error response
        if (!response.ok) {
          // get error message from body or default to response status
          const error = (data && data.message) || response.status;
          return Promise.reject(error);
        }
        alert("Added Service Successfully");
        navigation.navigate("ServiceList");
        // navigation.navigate("Home");
      })
      .catch((error) => {
        this.setState({ errorMessage: error.toString() });
        console.error("There was an error!", error);
      });
  };

  return (
    <View style={styles.container}>
      <View style={styles.inputView}>
        <TextInput
          style={styles.TextInput}
          placeholder="Service Name"
          placeholderTextColor="#000"
          onChangeText={(userName) => setServiceName(userName)}
        />
      </View>

      <View style={styles.inputView}>
        <TextInput
          style={styles.TextInput}
          placeholder="Price"
          placeholderTextColor="#000"
          // secureTextEntry={true}
          onChangeText={(price) => setPrice(price)}
        />
      </View>

      <View style={styles.inputView}>
        <TextInput
          style={styles.TextInput}
          placeholder="Description"
          placeholderTextColor="#000"
          // secureTextEntry={true}
          onChangeText={(price) => setDescription(price)}
        />
      </View>

      <TouchableOpacity style={styles.loginBtn} onPress={() => addService()}>
        <Text style={{ color: "#fff" }}> Add Service</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#011f4f",
    alignItems: "center",
    justifyContent: "center",
  },

  image: {
    marginBottom: 40,
  },

  inputView: {
    backgroundColor: "#fff",
    borderRadius: 30,
    width: "70%",
    height: 45,
    marginBottom: 20,

    alignItems: "center",
  },

  TextInput: {
    height: 50,
    flex: 1,
    padding: 10,
    marginLeft: 20,
    color: "#000",
  },

  forgot_button: {
    height: 30,
    width: "40%",
    // padding: 15,
    marginTop: 30,
    // backgroundColor: "#bdb4b3",
    borderRadius: 15,
  },

  loginBtn: {
    width: "75%",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 20,
    marginBottom: 40,

    backgroundColor: "#7a0800",
  },
  registerBtn: {
    width: "40%",
    borderRadius: 10,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    marginLeft: 0,
    backgroundColor: "#f5eeed",
  },
});
